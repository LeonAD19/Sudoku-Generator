//
// Created by Keshav Bhandari on 2/8/24.
//

/* These are header files used for the vectors,random num generators,
   and solve board "sudoku.h" in the "generator.cpp" */
#include <vector>
#include <random>
#include "../include/sudoku.h"


int** generateBoard(){
    // Following initialization is important
    int** BOARD = new int*[9];
    for(int i = 0; i < 9; i++){
        BOARD[i] = new int[9] {0, 0, 0, 0, 0, 0, 0, 0, 0};
    } //Initialization ends here

    // Step 1 Diagonal Fill Up
    // Step 2 Solve Sudoku
    // Step 3 Destroy Random Elements (Half Of It) 40 Elements
    // Step 4 Return The Board

    // First function. This is to generate a random num on the board and returns that random num
    // FUNCTION MAY BE COMPLETED NEED REVIEW OF WORK
    vector <int> randomizer () {
        vector <int> num = {1,2,3,4,5,6,7,8,9}

        random_device rd;
        mt19937 gen(rd());
        shuffle(num.begin(), num.end(), gen);

        return num;
    }
    // This function is to fill the each box randomly using a for loop
    // Function NOT COMPLETED NEED HELP
    void FillBoardRandom (int** BOARD, int start) {
        for (int start = 0; i < start + 3; i++) {
            for (int j = start; j < start + 3; j++)
        }
    }
    // Solving the board using the include sudoku.h
    solveBoard (BOARD, 0, 0);

    // Destroy the random elements using half of it
    // FUNCTION MAY BE COMPLETED NEED REVIEW OF WORK
    for (int i = 0; i < 10; ++i) {
        for (int j = 0; j < 10; ++j) {
            if (random() % 100 < 50) { // Randomly decide whether to delete the element
                BOARD[i][j] = 0; // Delete the element by assigning 0}
            }
        }
    }
    // Return the board??
    // Not sure how to return board need help


    /*BOARD[0] = new int[9] {0, 0, 4, 0, 5, 0, 0, 0, 0};
    BOARD[1] = new int[9] {9, 0, 0, 7, 3, 4, 6, 0, 0};
    BOARD[2] = new int[9] {0, 0, 3, 0, 2, 1, 0, 4, 9};
    BOARD[3] = new int[9] {0, 3, 5, 0, 9, 0, 4, 8, 0};
    BOARD[4] = new int[9] {0, 9, 0, 0, 0, 0, 0, 3, 0};
    BOARD[5] = new int[9] {0, 7, 6, 0, 1, 0, 9, 2, 0};
    BOARD[6] = new int[9] {3, 1, 0, 9, 7, 0, 2, 0, 0};
    BOARD[7] = new int[9] {0, 0, 9, 1, 8, 2, 0, 0, 3};
    BOARD[8] = new int[9] {0, 0, 0, 0, 6, 0, 1, 0, 0};
    return BOARD;*/
}