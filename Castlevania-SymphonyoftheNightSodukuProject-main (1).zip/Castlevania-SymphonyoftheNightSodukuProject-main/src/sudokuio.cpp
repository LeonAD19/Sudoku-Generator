//
// Created by Keshav Bhandari on 2/7/24.
//

/* This is the standard input/output stream library in C++.
It provides functionality for reading from and writing to the standard input/output streams, like cin, cout, cerr, etc. */
#include <iostream>
// Provides facilities for performing operations on file systems and their components, such as paths, regular files, and directories
#include <filesystem>
// Used for reading from and writing to files such as opening and closing files
#include <fstream>
//  It includes classes and functions for manipulating strings, such as std::string, std::getline()
#include <string>
// Gives access to the use of vectors
#include <vector>
// Used for searching, matching, and manipulating text based on patterns defined by regular expressions
#include <regex>
// Used to access the files of sudokuio.h
#include "../include/sudokuio.h"
// Used to access the files of sudoku.h
#include "../include/sudoku.h"
// This includes header files "library" so that you do not need to include std:: in your code
using namespace std;

// This function used to create a folder using the #include <filesystem>
void createFolder(const std::string& folderPath) {
    if (!filesystem::exists(folderPath)) {
        if (filesystem::create_directory(folderPath)) { // If the if statement runs true then outputs created folder
            std::cout << "Folder created successfully: " << folderPath << std::endl;
        } else {
            std::cerr << "Failed to create folder: " << folderPath << std::endl; // If statement runs else then outputs failed folder
        }
    } else {
        std::cout << "Folder already exists: " << folderPath << std::endl; // Final else statement the output is the folder is already created
    }
}

// Initializing a folder structure for storing data
void initDataFolder(){
    createFolder("data/"); // Created folder path for data
    createFolder("data/puzzles/"); // Created folder path for data/puzzles
    createFolder("data/solutions/"); // Created folder path for data/solutions
}

/* This function takes a 2D array BOARD representing a Sudoku board and a string content as parameters.
 It iterates through each row and column of the board. */
void boardToString(int** BOARD, string &content){
    for(int i = 0; i < 9; i++){ // Loop through each row of the Sudoku board
        for(int j = 0; j < 9; j++){ // Loop through each column of the Sudoku board
            string board_piece; // Variable to store the string representation of the current cell

            if (BOARD[i][j] == 0) content += "-"; // If the value of the current cell is 0, append "-" to the content string
            else content += to_string(BOARD[i][j]); // Otherwise, convert the value to string and append it to the content string

            if (j == 2 || j == 5)  content += " | "; // If the column index is at the end of a block (column 2 or 5), append " | " to the content string
            else content += " "; // Otherwise, append a space " " to the content string
        }
        if (i == 2 || i == 5) // If the row index is at the end of a block (row 2 or 5)
        {
            content += "\n"; // Append a newline "\n" to the content string to move to the next line
            for (int l = 0; l < 21; l++) content += "."; // Append a sequence of dots "." to the content string to represent horizontal separators between blocks
        }
        content += "\n"; // Append a newline "\n" to the content string to move to the next line after processing each row
    }
}

/* It takes a 2D array BOARD representing a Sudoku board and a filename as parameters.
 It initializes an empty string content.
 It calls the boardToString function to convert the Sudoku board into a string representation and stores it in content.
 It opens the file specified by the filename for writing. */
bool writeSudokuToFile(int** BOARD, const string& filename) {
    string content;
    boardToString(BOARD, content);
    ofstream outFile(filename); // Open file for writing
    if (outFile.is_open()) { // Using IF statement see if file can be opened
        outFile << content; // Write content to file
        outFile.close(); // Close the file
        cout << "Content has been written to the file: " << filename << endl;
        return true; // Indicate successful writing
    } else {
        cerr << "Unable to open file: " << filename << endl; // Indicate successful writing
        return false; // Indicate failure in writing
    }
}

// This function takes a string str, old character oldChar, and new character newChar as parameters.
void replaceCharacter(std::string& str, char oldChar, char newChar) {
    for (char &ch: str) { // Iterates through each character in the string str.
        if (ch == oldChar) { // If the character matches the oldChar, it replaces it with the newChar.
            ch = newChar;
        }
    }
}

void extractNumbers(const string& input, vector<int>& numbers) {
    regex regex("\\d+");

    auto iterator = sregex_iterator(input.begin(), input.end(), regex);
    auto end = sregex_iterator();

    for (; iterator != end; ++iterator) {
        numbers.push_back(stoi(iterator->str()));
    }
}

void fillBoard(const vector<int>& numbers, int **BOARD){
    for(int i = 0; i < 9; i++) {
        BOARD[i] = new int[9];
        for(int j = 0; j < 9; j++){
            BOARD[i][j] = numbers[i * 9 + j];
        }
    }
}

int** readSudokuFromFile(const string& filename){
    int** BOARD = new int*[9];
    vector<int> numbers;
    string sudoku;

    ifstream file(filename);
    sudoku = string(istreambuf_iterator<char>(file), istreambuf_iterator<char>());

    replaceCharacter(sudoku, '-', '0');
    extractNumbers(sudoku, numbers);
    fillBoard(numbers, BOARD);
    return BOARD;
}

bool checkIfSolutionIsValid(int** BOARD){
    for(int r = 0; r < 9; r++) {
        for(int c = 0; c < 9; c++) {
            int k = BOARD[r][c];
            BOARD[r][c] = 0;
            if(!isValid(BOARD, r, c, k)){
                BOARD[r][c] = k;
                cout << "!!!!!!!!!!!!!!!! TEST FAILED !!!!!!!!!!!!!!!!" << endl;
                return false;
            }
            BOARD[r][c] = k;
        }
    }
    cout << "--------------- TEST PASSED ---------------" << endl;
    return true;
}

vector<string> getAllSudokuInFolder(const string& folderPath){
    vector<std::string> sudokus;
    for (const auto& entry : filesystem::directory_iterator(folderPath)) {
        if (filesystem::is_regular_file(entry)) {
            sudokus.push_back(entry.path().string());
        }
    }
    cout << sudokus.size() << " Sudoku Puzzle found @ " << folderPath << endl;
    cout << setfill('-') << setw(55)<< "" << setfill(' ') <<endl;
    cout << setw(5) << "Index" << setw(50) << "File Name" << endl;
    cout << setfill('-') << setw(55)<< "" << setfill(' ') <<endl;
    for(int i = 0; i < sudokus.size(); i++)
        cout << setw(5) << i << setw(50) << sudokus[i] << endl;
    cout << setfill('-') << setw(55)<< "" << setfill(' ') <<endl;
    return sudokus;
}
