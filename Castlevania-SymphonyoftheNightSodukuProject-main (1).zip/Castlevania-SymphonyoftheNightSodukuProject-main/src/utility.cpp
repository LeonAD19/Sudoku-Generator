//
// Created by Keshav Bhandari on 2/8/24.
//

/* This is the standard input/output stream library in C++.
It provides functionality for reading from and writing to the standard input/output streams, like cin, cout, cerr, etc. */
#include <iostream>
//  It includes classes and functions for manipulating strings, such as std::string, std::getline()
#include <string>
// Gives access to the use of vectors
#include <vector>
// Used to access the files of generator.h
#include "../include/generator.h"
// Used to access the files of sudokuio.h
#include "../include/sudokuio.h"
// Used to access the files of sudoku.h
#include "../include/sudoku.h"
// This includes header files "library" so that you do not need to include std:: in your code
using namespace std;

// This function will return the filename
string getFileName(int index, const string &destination, const string &prefix){
    string index_str = to_string(index);
    string index_fill = string(4 - index_str.length(), '0');
    string filename = destination + index_fill + index_str + prefix + ".txt";
    return filename;
}
// This function will create and save a puzzle, it has the number of puzzles it has to create as a parameter as well as
// the destination to where to save the puzzle, and the index/prefix of the puzzle; this function will utilize a for
// loop to loop the number of puzzles needed; in the loop we will call the generateBoard function to randomly generate
// boards; we will then call the getFileNameFunction to  return the file name, we will use this file name as a parameter
// to call writeSodokoToFile to save our boardgits
void createAndSaveNPuzzles(const int& num_puzzles, const string& destination, const string& prefix){
    int total_success = 0;
    for(int i=0; i < num_puzzles; i++){
        int** BOARD = generateBoard();
        string filename = getFileName(i, destination, prefix);
        if(writeSudokuToFile(BOARD, filename)){
            total_success++;
            cout << "Successfully written(" << filename << ") "<< total_success << "of " << num_puzzles << endl;
        }else{
            cout << "!! Failed to write(" << filename << ") "<< total_success << "of " << num_puzzles << endl;
        }
    }
    cout << total_success << " files written out of " << num_puzzles <<endl;
}
/* This function holds the solve and save puzzle calling the solution. which takes the number of puzzles to solve,
the source directory containing puzzle files, the destination directory to save solution files,
and a prefix for the solution file names. */
void solveAndSaveNPuzzles(const int &num_puzzles, const string& source, const string& destination, const string& prefix){
    // Initializes the variables to int to count the successful runs and writes of the puzzle
    int total_success_solve = 0;
    int total_success_write = 0;
    // Obtains the path for all the sudoku puzzle files in the source directory
    vector<string> path_to_sudokus = getAllSudokuInFolder(source);

    /*Prints "Number of loaded puzzles:" this calls the sudoku path size and number of puzzles.
      This displays the number of loaded puzzles for the sudoku puzzle from the successful runs and writes. */
    cout << "Number of loaded puzzles:" << path_to_sudokus.size() << "/" << num_puzzles << endl;
    // Iterates over each sudoku puzzle file path obtained
    for(int i = 0; i < path_to_sudokus.size(); i++){
        // This indicates a pointer to a pointer to an integer indicating two dimensional array to the readSudokuFromFile
        int** sudoku = readSudokuFromFile(path_to_sudokus[i]);
        // This is an IF statement if the solveBoard sudoku puzzle is True
        if(solveBoard(sudoku, 0, 0)){
            // Is an IF statement to check if the solution is valid
            if(checkIfSolutionIsValid(sudoku)){
                // Increments the count of successful solved puzzles
                total_success_solve++;
                // Generates the file name for the corresponding solution using the getfile for the puzzle index, destination, and prefix
                string filename = getFileName(i, destination, prefix);
                // Outputs the progress of the successful solved solutions from path_to_sudokus.size()
                cout << "Puzzle Solved(over available): " << total_success_solve << "/" << path_to_sudokus.size() << " | ";
                cout << "Puzzle Solved(over total): " << total_success_solve << "/" << num_puzzles << endl;
                // Writes the solved sudoku puzzle to a file if the IF statement comes true
                if(writeSudokuToFile(sudoku, filename)){
                    // If the condition runs true then increments the count of successful solution files
                    total_success_write++;
                }
                // Output the progress of successful writes over the available and total sudoku puzzle solutions
                cout << "Puzzle Solved Written(over available): " << total_success_write << "/" << path_to_sudokus.size() << " | ";
                cout << "Puzzle Solved Written(over total): " << total_success_write << "/" << num_puzzles << endl;
            }
        }
    }
}
