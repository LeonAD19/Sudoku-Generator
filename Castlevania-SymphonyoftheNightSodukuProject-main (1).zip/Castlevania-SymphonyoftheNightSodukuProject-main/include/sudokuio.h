//
// Created by Keshav Bhandari on 2/7/24.
//

/* These include guards  are here to prevent the contents of the header file from being
 included multiple times in the same file unit causing errors. The "if not defined" #ifndef checks if the macro
 has not yet been defined in regards to "SUDOKUPROJECT_SUDOKU_H". The "#define" is used to define a macro
 being defined as regards to "SUDOKUPROJECT_SUDOKU_H". */
#ifndef SUDOKUPROJECT_SUDOKUIO_H
#define SUDOKUPROJECT_SUDOKUIO_H
// This includes header files for the use of vectors
#include<vector>
// This includes header files "library" so that you do not need to include std:: in your code
using namespace std;
// This function creates a folder at a specific path. Using the string& as a constant so that it may not change.
void createFolder(const std::string&);
// This function initializes the data folder
void initDataFolder();
// This function converts the sudoku board into a string. Hence the "int**" is pointer to pointer to a integer and then the "string&" representing the text.
void boardToString(int**, string&);
// Writes the sudoku board to file using "int**" and "string&" if it runs true
bool writeSudokuToFile(int**, const string&);
// This bool function replaces characters in a string with the other characters if runs true
void replaceCharacter(string&, char, char);
// Extracts the numbers from a string and stores them in a vector
void extractNumbers(const string&, vector<int>&);
// Fills the sudoku board with numbers from the vector
void fillBoard(const vector<int>&, int**);
// This function reads the sudoku board from file and returns it as a 2D array because of the "int**"
int** readSudokuFromFile(const string&);
// This true or false function checks if the solution is valid if it runs true then the argument "int**" is passed
bool checkIfSolutionIsValid(int**);
// This function retrieves all the sudoku files in the folder and returns the vector of strings
vector<string> getAllSudokuInFolder(const string&);
// This marks the end of the include file and closing the conditional inclusion block initiated by "#ifndef" from SUDOKUPROJECT_SUDOKUIO_H
#endif //SUDOKUPROJECT_SUDOKUIO_H
