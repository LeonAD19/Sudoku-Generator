//
// Created by Keshav Bhandari on 2/8/24.
//

/* These include guards  are here to prevent the contents of the header file from being
 included multiple times in the same file unit causing errors. The "if not defined" #ifndef checks if the macro
 has not yet been defined in regards to "SUDOKUPROJECT_UTILITY_H". The "#define" is used to define a macro
 being defined as regards to "SUDOKUPROJECT_UTILITY_H". */
#ifndef SUDOKUPROJECT_UTILITY_H
#define SUDOKUPROJECT_UTILITY_H
// Header file with a library including input and output operators such as std::cin and std::cout
#include <iostream>
// This includes header files "library" so that you do not need to include std:: in your code
using namespace std;
/* This is a declared function called "getFileName". There are three parameters int, const string& declared twice.
 The int represents the puzzle number. The const string& represents a reference passed to the path of the puzzle folder.
 The second const string& represents the puzzle prefix. */
string getFileName(int, const string &, const string &);
/* This is a declared function called "createAndSaveNPuzzles". It creates and saves the puzzle. The function takes the three parameters const int&, const string&, and const string&.
 The "const int&" references the number of puzzles to generate. The first "const string&" references the path to the puzzle folder.
 Lastly the second "const string&" references the puzzle prefix. */
void createAndSaveNPuzzles(const int&, const string&, const string&);
/* This is a declared function called "solveAndSaveNPuzzles". It solves and saves the puzzle. The function has four parameters const int& and three const string&.
 the "const int&" represent the number of puzzles solved. The first "const string&" passes a reference to a string representing the path to the puzzle folder.
 The second string passes a reference to a string representing the path to the solutions folder. The third string passes a reference to a string representing the solution prefix */
void solveAndSaveNPuzzles(const int &, const string&, const string&, const string&);
// This marks the end of the include file and closing the conditional inclusion block initiated by "#ifndef" from SUDOKUPROJECT_UTILITY_H
#endif //SUDOKUPROJECT_UTILITY_H
