//
// Created by Keshav Bhandari on 2/8/24.
//

/* These include guards  are here to prevent the contents of the header file from being
 included multiple times in the same file unit causing errors. The "if not defined" #ifndef checks if the macro
 has not yet been defined in regards to "SUDOKUPROJECT_GENERATOR_H". The "#define" is used to define a macro
 being defined as regards to "SUDOKUPROJECT_GENERATOR_H". */
#ifndef SUDOKUPROJECT_GENERATOR_H
#define SUDOKUPROJECT_GENERATOR_H
// This function is decalred as "int** generateBoard" which means it returns as a pointer to a pointer to a integer. Generating a new board.
int** generateBoard();
// This marks the end of the include file and closing the conditional inclusion block initiated by "#ifndef" from SUDOKUPROJECT_GENERATOR_H
#endif //SUDOKUPROJECT_GENERATOR_H
