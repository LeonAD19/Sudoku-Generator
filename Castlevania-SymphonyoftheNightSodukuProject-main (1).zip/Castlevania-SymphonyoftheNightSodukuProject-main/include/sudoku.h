//
// Created by Keshav Bhandari on 2/7/24.
//

/* These include guards  are here to prevent the contents of the header file from being
 included multiple times in the same file unit causing errors. The "if not defined" #ifndef checks if the macro
 has not yet been defined in regards to "SUDOKUPROJECT_SUDOKU_H". The "#define" is used to define a macro
 being defined as regards to "SUDOKUPROJECT_SUDOKU_H". */
#ifndef SUDOKUPROJECT_SUDOKU_H
#define SUDOKUPROJECT_SUDOKU_H
/* The void printBoard function takes a pointer to a pointer integer. This takes the function to a 2D array as an argument.
 the other three integers represents the dimensions of the board */
void printBoard(int**, int, int, int);
/* This bool statement runs the code if true or false statement. If True "isValid" then it is checking to place the certain number of int on the board.
 Such as the "int**" places a pointer to a pointer to an integer representing the 2D array, the second int representing the row index,
 the third int representing the column index, and the fourth int representing the numbers in the row and column. */
bool isValid(int**, int, int, int);
/* This bool statement checks whether or not the function runs true. It attempts to solve the sudoku board recursively.
 So the int is assigned to a pointer to a pointer to a integer, the second int represents the rows, and the third representing the columns.
 If the bool returns false and exhausts all other possibilities for finding that valid number,
 the board is then not solved triggering to backtrack to the previous cell on the board and tries a different number. */
bool solveBoard(int**, int, int);
// This function is decalred as "int** generateBoard" which means it returns as a pointer to a pointer to a integer. Generating a new board.
int** generateBoard();
// This marks the end of the include file. Closing the conditional inclusion block initiated by "#ifndef" from SUDOKUPROJECT_SUDOKU_H
#endif //SUDOKUPROJECT_SUDOKU_H
