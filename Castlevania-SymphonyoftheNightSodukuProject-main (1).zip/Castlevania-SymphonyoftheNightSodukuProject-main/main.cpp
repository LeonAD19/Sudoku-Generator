/* This is the standard input/output stream library in C++.
It provides functionality for reading from and writing to the standard input/output streams, like cin, cout, cerr, etc. */
#include <iostream>
// Used to access the files of sudoku.h
#include "include/sudoku.h"
// Used to access the files of sudokuio.h
#include "include/sudokuio.h"
// Used to access the files of utility.h
#include "include/utility.h"

/* Define the file paths for the puzzle data and solution.
The path to puzzles variable holds the path where the sudoku puzzle
files will be stored. The path solutions variable holds the path where
the sudoku solution files will be stored. */
string PATH_TO_PUZZLES = "data/puzzles/";
string PATH_TO_SOLUTIONS = "data/solutions/";

/* Define the file prefixes for the puzzle and solutions.
This allows the puzzle prefix to number the puzzle 1 to 10.
The solution prefix is used for naming the files that store the solution
in the sudoku puzzle */
string PUZZLE_PREFIX = "PUZZLE";
string SOLUTION_PREFIX = "SOLUTION";

// Initializes the number of puzzles generated to an integer of 10
int NUM_PUZZLE_TO_GENERATE = 10;

// Int main is the main function of the code that is an integer.
int main() {
    // Initializes the data folder where the puzzle data and solutions will be stored
    initDataFolder();
    // Generates the number of sudoku puzzles
    createAndSaveNPuzzles(NUM_PUZZLE_TO_GENERATE, PATH_TO_PUZZLES, PUZZLE_PREFIX);
    // Solves the generated puzzle
    solveAndSaveNPuzzles(NUM_PUZZLE_TO_GENERATE, PATH_TO_PUZZLES, PATH_TO_SOLUTIONS, SOLUTION_PREFIX);
    // Exit the program
    return 0;
}


