//
// Created by Keshav Bhandari on 2/8/24.
//

#ifndef SUDOKUPROJECT_GENERATOR_H
#define SUDOKUPROJECT_GENERATOR_H
int** generateBoard();
#endif //SUDOKUPROJECT_GENERATOR_H
