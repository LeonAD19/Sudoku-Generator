# for windows user please use CLion or follow instructions similar from SudokuProject
mkdir -p ./cmake-build-debug
cmake -B ./cmake-build-debug
cmake --build ./cmake-build-debug
echo "----------------------------------------"
echo "------------COMPILATION DONE------------"
echo "----------------------------------------"

cd cmake-build-debug

./EldenRingQuestTracker