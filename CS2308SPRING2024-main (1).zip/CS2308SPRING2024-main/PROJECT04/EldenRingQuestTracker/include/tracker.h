//
// Created by Keshav Bhandari on 4/9/24.
//

#ifndef ELDENRINGQUESTTRACKER_TRACKER_H
#define ELDENRINGQUESTTRACKER_TRACKER_H

#include "../include/quest.h"
#include <string>
using namespace std;
namespace fs = filesystem;

class QuestTracker : public Quest{
    private:
        string player;
        string cached_quest_path;
        string source_quest_path;
        string source_dir;
        string cached_dir;
    public:
        QuestTracker(const string&, const string&, const string&, const string&);
        bool saveQuest();
        bool markComplete(const int&);
        bool markInProgress(const int&);
        bool markInComplete(const int&);
        size_t getCompletedCount() const;
        size_t getTotalTaskCount() const;
};

#endif //ELDENRINGQUESTTRACKER_TRACKER_H
