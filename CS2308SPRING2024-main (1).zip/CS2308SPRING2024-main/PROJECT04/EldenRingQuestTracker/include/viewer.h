//
// Created by Keshav Bhandari on 4/9/24.
//

#ifndef ELDENRINGQUESTTRACKER_VIEWER_H
#define ELDENRINGQUESTTRACKER_VIEWER_H

#include <iostream>
#include <vector>
#include <filesystem>
#include <iomanip>
#include "tracker.h"

using namespace std;
namespace fs = filesystem;

class Viewer{
    private:
        string source_dir;
        string cached_dir;
    public:
        Viewer(const string&, const string&);

        vector<string> getSourceQuests();
        vector<string> getCachedPlayers();

        void questMenu(QuestTracker&);
        void optionsMenu(const string&, const string&);
        void homeMenu();
        void serve();
};

#endif //ELDENRINGQUESTTRACKER_VIEWER_H
