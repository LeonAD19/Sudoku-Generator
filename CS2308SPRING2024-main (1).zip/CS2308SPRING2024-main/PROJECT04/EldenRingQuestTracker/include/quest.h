//
// Created by Keshav Bhandari on 4/9/24.
//

#ifndef ELDENRINGQUESTTRACKER_QUEST_H
#define ELDENRINGQUESTTRACKER_QUEST_H

#include <iostream>
#include <string>
#include <vector>
#include <fstream>

using namespace std;
namespace fs = filesystem;

class Quest{
    private:
        string quest_file;
        string description;
        string main_npc;
        string impacted_npcs;
        string rewards;

    protected:
        vector<string> tasks;

    public:
        Quest(const string&);
        bool loadQuest(const string&);

        string metaDataView() const;
        string tasksView() const;
        string questView() const;

        template <typename... Args>
        string getQuestPathFrom(Args&&... args){
            string result, separator="/";
            ((result += forward<Args>(args) + separator), ...);
            return result + this->quest_file;
        }
};
#endif //ELDENRINGQUESTTRACKER_QUEST_H
