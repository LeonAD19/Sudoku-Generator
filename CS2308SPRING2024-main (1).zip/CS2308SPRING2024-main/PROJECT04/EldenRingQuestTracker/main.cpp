/*
Documentation Required!!!
*/
#include "include/viewer.h"
#define SOURCE_DIR "DATA/QUESTS"
#define CACHED_DIR "DATA/PROGRESS"

using namespace std;



int main(int argc, char **argv) {
    if (argc == 3){
        Viewer viewer(argv[1],    argv[2]);
        viewer.serve();
    }
    else{
        Viewer viewer(SOURCE_DIR, CACHED_DIR);
        viewer.serve();
    }
    return 0;
}
