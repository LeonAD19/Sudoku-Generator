# Objective

- To put your skills to real tests.

## Read Carefully

- Requires C++17 or higher.
- Recommended tool: CLion.
- Use CMake for project build.
- To avoid problems, use CLion.
- If using CLion, reload the CMake configuration via `File->Reload CMake Project`.
- Create a private Git (txstate) repository named `TeamNameEldenRingQuestTracker` (e.g., Team Name: FarCry 6, Git Repo: FarCry6EldenRingQuestTracker) and add `me(k_b459@txstate.edu)` and `DIA(k_m825@txstate.edu)` as collaborators.
- Submit a PDF in Canvas containing:
  - Link to your repository.
  - Name and NetID of each contributor with their roles.
  - Up to 4 group photos.
  - Note if the photo is shareable.

### For Non-CLion, VSCode Users

- Install CMake (minimum version 3.27).
- Install the CMake extension for VS Code via the Extension Manager.
- Open GitBash (mac users can use the default terminal), ensure your current directory is the project root, then run: `sh run.sh` to compile and run the program.

## Testing Your Code

- Run `sh test.sh` in the terminal from the project working directory.
- This script executes the compiled code with 100 inputs provided in `test.sh`, saving the output at `cmake-build-debug/TESTS/PROGRAM_OUTPUT`.
- It then compares this output with the expected output in `cmake-build-debug/TEST/EXPECTED_OUTPUT`.
- Your program must pass all 100 tests.

## Grading Criteria

- Total: 100 points.
- 10 points - Group Work Photos.
- 10 points - Being Nice.
- 20 points - Passing all tests.

## Project Organization

- `include-folder`: Contains all header files with class and function declarations.
- `src-folder`: Contains the source code implementing the headers.
- `run.sh`: Shell script for compiling and running the program (not needed for CLion users).
- `cmake-build-debug/DATA` folder: Contains data files.
- `cmake-build-debug/DATA/QUESTS`: Contains all available quests. Check the input pattern for understanding.
- `cmake-build-debug/DATA/PROGRESS`: Saves current progress per player. For 'bulbul', progress is saved at `cmake-build-debug/DATA/PROGRESS/bulbul/` with text files for each quest line.
- `cmake-build-debug/DATA/TESTS`: Maintains test cases.
- `cmake-build-debug/DATA/TESTS/EXPECTED_OUTPUT`: Contains expected test case outcomes for program evaluation.
- `cmake-build-debug/DATA/TESTS/PROGRAM_OUTPUT`: Stores program output from tests for comparison with `EXPECTED_OUTPUT`.

## Reference for the input

- [ref-01: Elden Ring - All Sidequests](https://www.rockpapershotgun.com/elden-ring-all-sidequests)
- [ref-02: Elden Ring Wiki - Side Quest](https://eldenring.wiki.fextralife.com/Side+Quest)
