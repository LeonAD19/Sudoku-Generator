//
// Created by Keshav Bhandari on 4/9/24.
//
#include "../include/viewer.h"
Viewer::Viewer(const string& source_dir, const string& cached_dir):
               source_dir(source_dir), cached_dir(cached_dir){}

vector<string> Viewer::getSourceQuests(){
    /*
        This functions returns available quests fromt he folder DATA/QUESTS
    */
    vector<string> quests = {};
    // Check if the given path exists and is a directory
    if (fs::exists(this->source_dir) && fs::is_directory(this->source_dir)){
        // Use a directory_iterator to go through the directory
        for (const auto& entry: fs::directory_iterator(this->source_dir)){
            // Check if the entry is a regular file and has a .txt extension
            if (entry.is_regular_file() && entry.path().extension() == ".txt"){
                quests.push_back(entry.path().filename());
            }
        }
    }
    return quests;
}
vector<string> Viewer::getCachedPlayers(){
    /*
        This functions returns available players fromt he folder DATA/PROGRESS/
    */
    vector<string> players = {};
    // Check if the given path exists and is a directory
    if (fs::exists(this->cached_dir) && fs::is_directory(this->cached_dir)){
        // Use a directory_iterator to go through the directory
        for (const auto& entry: fs::directory_iterator(this->cached_dir)){
            // Check if the entry is a directory
            if (entry.is_directory()){
                players.push_back(entry.path().filename());
            }
        }
    }
    return players;
}

void Viewer::homeMenu() {
    /*
    TODO!!! Documentation required...
    */

    /*
    TODO!!! Instructions
    In following two incomplete lines initialize variable quests, cached_players of type vector of string
    1. Initialize quests value with the available quest, you can do this by calling getSourceQuests member function
    2. Initialize cached_players with available players, you can do this by calling getCachedPlayers member function
    */
    vector<string> quests  = /*??*/;
    vector<string> cached_players = /*??*/;

    size_t quest_id = 0;
    string player;

    cout << "Available Quests to Track...." << endl;
    for(int i = 0; i < quests.size(); i++) {
        cout << "QUEST [" << setw(2) << i+1 << "]. " << quests[i] << endl;
    }
    cout << endl;
    cout << "--------------------------------" << endl;
    cout << "   HOME MENU: Enter QuestID     " << endl;
    cout << "--------------------------------" << endl;
    while(quest_id > quests.size() || quest_id < 1) {
        cout << "Enter Valid QuestID (options: 1, 2, ...) to track desired quest: ";
        cin >> quest_id;
    }

    cout << "Available Cached Player Profiles.." << endl;
    for (int i = 0; i < cached_players.size(); i++){
        cout << setw(2) << i+1 << ". " << cached_players[i] << endl;
    }
    cout << endl;
    cout << "--------------------------------" << endl;
    cout << "   HOME MENU: Enter Player      " << endl;
    cout << "--------------------------------" << endl;

    cout << "Type Player's name to Create/Update the progress: ";
    cin >> player;

    this->optionsMenu(player, quests[quest_id - 1]);
}

void Viewer::optionsMenu(const string& player, const string& quest_file){
    /*
    TODO!!! Documentation required...
    */
    /*
    TODO!!! 
    Initialize the QuestTracker object with appropriate attributes from the current class
    */
    QuestTracker qtracker(/*??*/, /*??*/, /*??*/, /*??*/);
    string repeat="y";
    while(repeat == "y" || repeat == "Y"){
        this->questMenu(qtracker);
        cout << "\n" << qtracker.tasksView() << endl;
        cout << "Continue updating the quest..? [Enter y/Y to continue] ";
        cin >> repeat;
    }
    cout << "Do you want to save the current progress ? (y/Y) ";
    cin >> repeat;
    if(repeat == "y" || repeat == "Y") qtracker.saveQuest();
}

void Viewer::questMenu(QuestTracker& qtracker) {
    /*
    TODO!!! Documentation required...
    */
    int action_id = 0, task_id = 0, total_task = qtracker.getTotalTaskCount();

    cout << "Showing selected quest.............." << endl;
    /*
    TODO!!! 
    Please follow the instructions and compelte the code
    */
    cout << /*Get quest view from QuestTracker instance*/ << endl;
    cout << endl;
    cout << /*Get total completed count from QuestTracker instance*/ << " / ";
    cout << /*Get total task count from QuestTracker instance*/ << "Completed" << endl;

    cout << "--------------------------------" << endl;
    cout << "   QUEST ACTION: Choose action  " << endl;
    cout << "--------------------------------" << endl;

    cout << "Choose from following: " << endl;
    cout << "Action  1: Mark Completed" << endl;
    cout << "Action  2: Mark InProgress" << endl;
    cout << "Action  3: Mark InCompleted" << endl;

    while(action_id < 1 || action_id > 3){
        cout << "Select Valid Action ID?(Enter 1, 2 or 3): ";
        cin >> action_id;
    }

    while(task_id < 1 || task_id > total_task){
        cout << "Select Valid Task ID?(Between 1, and " << total_task << "): ";
        cin >> task_id;
    }
    TODO!!! 
    Please follow the instructions and compelte the code
    */
    if      (action_id == 1) qtracker./*Choose appropriate method*/(task_id);
    else if (action_id == 2) qtracker./*Choose appropriate method*/(task_id);
    else                     qtracker./*Choose appropriate method*/(task_id);
}


void Viewer::serve(){
    /*
    TODO!!! Documentation required...
    */
    string startover = "y";
    while(startover == "y" || startover == "Y"){
        this->homeMenu();
        cout << "Do you want to start over? (y/n): ";
        cin >> startover;
    }
}