//
// Created by Keshav Bhandari on 4/9/24.
//
/*
TODO!!!!: Documentation Required here...
*/
#include "../include/quest.h"

Quest::Quest(const string& quest_file): quest_file(quest_file) {}

bool Quest::loadQuest(const string& filename){
    /*
    TODO!!!!: Documentation Required here...
    */
    ifstream file(filename);
    string line;
    int line_number = 0;
    if (!file.is_open()) return false;

    while (getline(file,line)){
        /*
            TODO!!!!: Instructions..
            Study any sample input file from cmake-build-debug/DATA/QUESTS/
            > Figure out what line number goes to what this->attribute of this class
            > First if statement is done for your reference
            > Replace the comment section with appropriate values
        */
        if      (line_number ==  1)        this->description   = line;
        else if (line_number ==  /*??*/)   /*??*/              = line;
        else if (line_number ==  /*??*/)   /*??*/              = line;
        else if (line_number ==  /*??*/)   /*??*/              = line;
        else if (line_number >=  /*??*/)   /*??*/;
        line_number++;
    }
    return true;
}

string Quest::metaDataView() const{
    /*
        TODO!!! Documentation Required
    */
    string view;
    /*
        TODO!!!!: Instructions..
        Study any sample input file from cmake-build-debug/DATA/QUESTS/
        Figure out what to replace following ?? field
    */
    view += "Description:\n"    + /*??*/ + "\n\n";
    view += "Main NPC:\n"       + /*??*/ + "\n\n";
    view += "Impacted NPCs:\n"  + /*??*/ + "\n\n";
    view += "Rewards:\n"        + /*??*/ + "\n\n";
    view += "Tasks:\n";
    return view;
}
string Quest::tasksView() const{
    /*
        TODO!!! Documentation Required
    */
    string view;
    for(const string& task: this->tasks){
        view += task + "\n";
    }
    view.pop_back(); // Remove last \n
    return view;
}
string Quest::questView() const{
    /*
        TODO!!! Documentation Required
    */
    /*
        TODO!!!!: Instructions..
        QuestView is the entire view of text file
        You can achieve this by concatenating the metaDataView and taskView
        Return appropriate string as an output
    */
    return /**??*/;
}