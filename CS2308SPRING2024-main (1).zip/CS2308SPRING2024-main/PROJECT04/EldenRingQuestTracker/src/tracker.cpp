//
// Created by Keshav Bhandari on 4/9/24.
//
#include "../include/tracker.h"

QuestTracker::QuestTracker(const string& source_dir,
                           const string& cached_dir,
                           const string& player,
                           const string& quest_file):
                           source_dir(source_dir),
                           cached_dir(cached_dir),
                           player(player),
                           Quest(quest_file) {
    this->cached_quest_path = this->getQuestPathFrom(cached_dir, player);
    this->source_quest_path = this->getQuestPathFrom(source_dir);

    if(this->loadQuest(this->cached_quest_path)){
        cout << "Loading quest from current progress @ " << this->cached_quest_path << endl;
    }else if(this->loadQuest(this->source_quest_path)){
        cout << "Loading new quest from " << this->source_quest_path << endl;
    }else{
        cout << "Warning!! Error Loading Quest!!" << endl;
    }
}

bool QuestTracker::saveQuest(){
    /*
        Saves the current progress to file, DATA/PROGRESS/PLAYER_NAME/qeust_file.txt
    */
    fs::path filePath = this->cached_quest_path;
    // Ensure the parent directory exists
    if (fs::create_directories(filePath.parent_path())) {
        cout << "Parent directory created: " << filePath.parent_path() << endl;
    }
    // Open the file for writing (this will create the file if it doesn't exist)
    ofstream outFile(filePath);
    // Check if the file stream is open/valid
    if (!outFile) {
        cout << "Failed to open the file for writing: " << filePath << endl;
        return false;
    }
    // Write the string to the file
    outFile << this->questView();
    cout << "Progress cached successfully @: " << filePath << endl;
    return true;
    // File is automatically closed when outFile goes out of scope
}

bool QuestTracker::markComplete(const int & task_id) {
    /*
        TODO!!! Documentation Required
    */
    if(task_id > this->tasks.size() || task_id < 1) return false;
    /*
        TODO!!!!: Instructions..
        quest base class has vector<string> tasks attributes
        which contains all the required tasks from the quest line
        E.g., for patches quest you will have following members in vectors
        (note only shown few for the example ....)
        {
            "[ ] 01. Defeat Patches in Murkwater Cave, but don't kill him or you'll end this quest prematurely.",
            "[ ] 02. Reload the area, then speak to him again and open his chest. Return and forgive him.",
            "[ ] 03. Find him at Scenic Isle, then again on Mt. Gelmir near the First Mt. Gelmir Campsite Grace. Follow his Rainbow Stone trail and he will push you off a cliff."
        }
        
        the value of task_id goes from 1...size_of_task
        given task_id, example: 2, you have to mark all previous task complete and future incomplete
        here, 01, 02 will be completed and marekd from [ ] -> [x], 03 will be marked from [ ] -> [ ]
    */
    for(int i = 0; i < tasks.size(); i++) {
        if(i < task_id
            // Grap ith member of the tasks from vector and replace the 1st position of string x
            /*??*/;
        else
            // Grap ith member of the tasks from vector and replace the 1st position of string ' ' empty string
            /*??*/;
    }
    return true;
}

bool QuestTracker::markInComplete(const int & task_id) {
    /*
        TODO!!! Documentation Required
    */
    if(task_id > this->tasks.size() || task_id < 1) return false;
    // As in above example, but here if you mark task_id incomplete, everything above that task_id 
    // should be incomplete and below should be complete
    for(int i = 0; i < tasks.size(); i++) {
        if(i < task_id - 1)
            // Grap ith member of the tasks from vector and replace the 1st position of string x
            /*??*/;
        else
            // Grap ith member of the tasks from vector and replace the 1st position of string ' ' empty string
            /*??*/;
    }
    return true;
}

bool QuestTracker::markInProgress(const int & task_id) {
    /*
        TODO!!! Documentation Required
    */
    if(task_id > this->tasks.size() || task_id < 1) return false;
    // As in above example, but if you mark task_id inProgress, everything above that task_id 
    // should be incomplete and below should be complete
    for(int i = 0; i < tasks.size(); i++) {
        if(i < task_id - 1)
            // Grap ith member of the tasks from vector and replace the 1st position of string x
            /*??*/;
        else if(i == task_id - 1)
            // Grap ith member of the tasks from vector and replace the 1st position of string *
            /*??*/;
        else
            // Grap ith member of the tasks from vector and replace the 1st position of string ' '
            /*??*/;
    }
    return true;
}

size_t QuestTracker::getCompletedCount() const{
    /*
        TODO!!! Documentation Required
    */
    size_t count = 0;
    for(const auto & task : this->tasks){
        // Grap each task from tasks and increment count only if the first occurence is 'x'
        /*??*/;
    }
    return count;
}

size_t QuestTracker::getTotalTaskCount() const{return this->tasks.size();}