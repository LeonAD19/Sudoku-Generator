#!/bin/bash
# Simulate typing "John Doe" and "25", followed by newlines
cd cmake-build-debug
INPUT_DIR="DATA/QUESTS"
OUTPUT_DIR="DATA/TESTS/PROGRAM_OUTPUT"

save_test_result() {
  for item in "$@"; do
    echo "$item"
  done | ./EldenRingQuestTracker $INPUT_DIR $OUTPUT_DIR
}
#
save_test_result 3 sample_001 3 2 n y n
save_test_result 1 sample_002 1 6 n y n
save_test_result 2 sample_003 1 1 n y n
save_test_result 3 sample_004 2 4 n y n
save_test_result 3 sample_005 2 2 n y n
save_test_result 1 sample_006 2 4 n y n
save_test_result 1 sample_007 1 2 n y n
save_test_result 2 sample_008 1 3 n y n
save_test_result 2 sample_009 1 1 n y n
save_test_result 3 sample_010 2 1 n y n
save_test_result 2 sample_011 3 6 n y n
save_test_result 3 sample_012 1 5 n y n
save_test_result 3 sample_013 1 5 n y n
save_test_result 2 sample_014 2 7 n y n
save_test_result 2 sample_015 3 2 n y n
save_test_result 2 sample_016 3 2 n y n
save_test_result 2 sample_017 2 2 n y n
save_test_result 1 sample_018 2 7 n y n
save_test_result 2 sample_019 1 2 n y n
save_test_result 1 sample_020 3 3 n y n
save_test_result 2 sample_021 1 1 n y n
save_test_result 2 sample_022 2 2 n y n
save_test_result 3 sample_023 2 1 n y n
save_test_result 2 sample_024 1 4 n y n
save_test_result 3 sample_025 1 3 n y n
save_test_result 3 sample_026 1 5 n y n
save_test_result 3 sample_027 2 2 n y n
save_test_result 1 sample_028 1 3 n y n
save_test_result 3 sample_029 3 2 n y n
save_test_result 1 sample_030 3 2 n y n
save_test_result 1 sample_031 3 7 n y n
save_test_result 2 sample_032 2 1 n y n
save_test_result 2 sample_033 2 2 n y n
save_test_result 1 sample_034 2 2 n y n
save_test_result 3 sample_035 1 1 n y n
save_test_result 1 sample_036 2 4 n y n
save_test_result 2 sample_037 2 7 n y n
save_test_result 3 sample_038 2 5 n y n
save_test_result 1 sample_039 2 5 n y n
save_test_result 3 sample_040 3 1 n y n
save_test_result 1 sample_041 3 1 n y n
save_test_result 2 sample_042 2 7 n y n
save_test_result 2 sample_043 3 1 n y n
save_test_result 2 sample_044 2 2 n y n
save_test_result 2 sample_045 2 5 n y n
save_test_result 2 sample_046 1 5 n y n
save_test_result 1 sample_047 3 7 n y n
save_test_result 2 sample_048 2 1 n y n
save_test_result 1 sample_049 2 5 n y n
save_test_result 1 sample_050 1 1 n y n
save_test_result 2 sample_051 1 7 n y n
save_test_result 3 sample_052 2 3 n y n
save_test_result 3 sample_053 3 2 n y n
save_test_result 3 sample_054 3 3 n y n
save_test_result 1 sample_055 2 6 n y n
save_test_result 1 sample_056 2 4 n y n
save_test_result 2 sample_057 2 6 n y n
save_test_result 2 sample_058 3 4 n y n
save_test_result 3 sample_059 2 3 n y n
save_test_result 3 sample_060 1 1 n y n
save_test_result 3 sample_061 1 1 n y n
save_test_result 3 sample_062 3 5 n y n
save_test_result 1 sample_063 3 7 n y n
save_test_result 3 sample_064 1 7 n y n
save_test_result 1 sample_065 2 2 n y n
save_test_result 2 sample_066 3 6 n y n
save_test_result 1 sample_067 2 7 n y n
save_test_result 1 sample_068 1 7 n y n
save_test_result 1 sample_069 1 2 n y n
save_test_result 3 sample_070 3 3 n y n
save_test_result 2 sample_071 3 2 n y n
save_test_result 3 sample_072 3 3 n y n
save_test_result 3 sample_073 3 5 n y n
save_test_result 1 sample_074 1 1 n y n
save_test_result 3 sample_075 2 4 n y n
save_test_result 3 sample_076 2 1 n y n
save_test_result 3 sample_077 2 1 n y n
save_test_result 3 sample_078 1 3 n y n
save_test_result 1 sample_079 2 5 n y n
save_test_result 3 sample_080 2 3 n y n
save_test_result 3 sample_081 1 1 n y n
save_test_result 1 sample_082 3 1 n y n
save_test_result 1 sample_083 2 1 n y n
save_test_result 3 sample_084 1 1 n y n
save_test_result 1 sample_085 1 3 n y n
save_test_result 2 sample_086 2 1 n y n
save_test_result 3 sample_087 3 3 n y n
save_test_result 3 sample_088 1 5 n y n
save_test_result 3 sample_089 3 7 n y n
save_test_result 2 sample_090 3 4 n y n
save_test_result 1 sample_091 3 7 n y n
save_test_result 3 sample_092 1 2 n y n
save_test_result 2 sample_093 3 1 n y n
save_test_result 1 sample_094 1 3 n y n
save_test_result 2 sample_095 2 7 n y n
save_test_result 1 sample_096 3 1 n y n
save_test_result 1 sample_097 2 6 n y n
save_test_result 2 sample_098 1 5 n y n
save_test_result 1 sample_099 2 2 n y n
save_test_result 1 sample_100 1 4 n y n


# Path to the directories
expected_dir="DATA/TESTS/EXPECTED_OUTPUT"
program_dir="DATA/TESTS/PROGRAM_OUTPUT"

# Counter for passed tests
passed_tests=0
total_tests=0

# Iterate through the expected output directories
for test_dir in "$expected_dir"/*; do
    if [ -d "$test_dir" ]; then  # Check if it's a directory
        test_name=$(basename "$test_dir")
        echo "Checking test: $test_name"

        # Compare each file in the expected output directory
        for expected_file in "$test_dir"/*; do
            if [ -f "$expected_file" ]; then  # Check if it's a file
                file_name=$(basename "$expected_file")
                program_file="$program_dir/$test_name/$file_name"

                # Check if the corresponding program output file exists
                if [ -f "$program_file" ]; then
                    # Use diff to compare the files
                    if diff -q "$expected_file" "$program_file" > /dev/null; then
                        echo "Test $test_name/$file_name passed."
                        ((passed_tests++))
                    else
                        echo "Test $test_name/$file_name failed."
                    fi
                    ((total_tests++))
                else
                    echo "Program output file $program_file does not exist."
                fi
            fi
        done
    fi
done

echo "Total tests: $total_tests"
echo "Passed tests: $passed_tests"