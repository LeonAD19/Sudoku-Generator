#include <iostream>
using namespace std;

void printBoard(int, int, int);
bool isValid(int, int, int);
bool solveBoard(int, int);

// Defining the board globally
int BOARD[9][9] = {
		// 0  1  2    	3  4  5     6  7  8
	/*0*/ {0, 0, 4, 	0, 5, 0, 	0, 0, 0},
	/*1*/ {9, 0, 0, 	7, 3, 4, 	6, 0, 0},
	/*2*/ {0, 0, 3, 	0, 2, 1, 	0, 4, 9},

	/*3*/ {0, 3, 5, 	0, 9, 0, 	4, 8, 0},
	/*4*/ {0, 9, 0, 	0, 0, 0, 	0, 3, 0},
	/*5*/ {0, 7, 6, 	0, 1, 0, 	9, 2, 0},

	/*6*/ {3, 1, 0, 	9, 7, 0, 	2, 0, 0},
	/*7*/ {0, 0, 9, 	1, 8, 2, 	0, 0, 3},
	/*8*/ {0, 0, 0, 	0, 6, 0, 	1, 0, 0}};

// printBoard: Prints the board depending on the input
void printBoard(int r, int c, int k)
{
	/* if k is valid at r,c print showing green colored k at r, c else red colored k
	it will print default sudoku board if k is 0*/
	for (int i = 0; i < 9; i++)
	{
		for (int j = 0; j < 9; j++)
		{
			// Two things can happen here, either k == 0, 
			// you want to print default board
			// Or k = some value and you want to print green or red based on validity of the choice
			string board_piece = "";
			if (BOARD[i][j] == 0)
				board_piece = "\x1B[93m" + to_string(BOARD[i][j]) + "\x1B[0m"; // Yellow
			else
				board_piece = to_string(BOARD[i][j]); // White

			if (i == r && j == c)
			{
				if (isValid(r, c, k))
					board_piece = "\x1B[32m" + to_string(k) + "\x1B[0m"; // Green
				else
					board_piece = "\x1B[31m" + to_string(k) + "\x1B[0m"; // Red
			}

			cout << board_piece;

			if (j == 2 || j == 5)
				cout << " | ";
			else
				cout << " ";
		}
		if (i == 2 || i == 5)
		{
			cout << endl;
			for (int l = 0; l < 21; l++)
				cout << ".";
		}
		cout << endl;
	}
}

bool isValid(int r, int c, int k)
{
	// check if k exists in row, BOARD[r][i],
	// check if k exists in col, BOARD[i][c],
	for (int i = 0; i < 9; i++)
	{
		if (k == BOARD[r][i] || k == BOARD[i][c])
			return false;
	}

	// check if k exists in the box
	for (int i = 3 * (r / 3); i < 3 * (r / 3) + 3; i++)
	{
		for (int j = 3 * (c / 3); j < 3 * (c / 3) + 3; j++)
		{
			if (k == BOARD[i][j])
				return false;
		}
	}
	return true;
}

bool solveBoard(int r=0, int c=0){
	if(r == 9)
		return true;
	else if(c == 9)
		return solveBoard(r+1, 0);
	else if(BOARD[r][c] != 0)
		return solveBoard(r, c+1);
	else{
		for(int k=1; k<10; k++){
			printBoard(r,c,k);
			cout << "#######################" << endl;
			if(isValid(r, c, k)){
				BOARD[r][c] = k;
				if(solveBoard(r, c+1))
					return true;
				else
					BOARD[r][c] = 0;
			}
		}
		return false;
	}
}

int main()
{
	solveBoard();
	return 0;
}
