#include <iostream>
using namespace std;
int main(){
    int b = 2;
    int* a = &b;
    cout << a << endl; // This will give us the address of b
    cout << *a << endl; // This will give us the value of b, because * is resolution operator
    // Don't play with semantics, int *a is just as int* a, but your interpretation might make you think differently
    return 0;
}