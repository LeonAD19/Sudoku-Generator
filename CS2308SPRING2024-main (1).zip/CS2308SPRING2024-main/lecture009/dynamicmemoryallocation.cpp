#include <iostream>
using namespace std;

int* getArray(int size){
    int* arr = new int[size];
    return arr;
}
int** get2DArray(int rows, int cols){
    int** arr = new int*[rows];
    for(int i = 0; i < rows; i++){
        arr[i] = new int[cols];
    }
    return arr;
}

int main(int argc, char const *argv[])
{
    int size = 6;
    // This is how you create array dynamically
    int* arr = new int[size]; // option 1, where you intend to fill this array later on using for loop
    int* arr_1 = new int[size]{1, 2, 3, 4, 5, 6}; // option 2, you initialize default

    // What if I want to create a function that creates array on fly and return to me
    int* new_arr = getArray(size);//int* getArray(int);

    // What about 2D arrays? example you want to create 3 by 2
    int** arr_dp = new int*[3];
    for(int i = 0; i < 3; i++)
        arr_dp[i] = new int[2];
    // What about a function that returns this array


    return 0;
}
