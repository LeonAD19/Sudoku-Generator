#include <iostream>
#include <iomanip>
#include <random>
#include <cmath>
using namespace std;

// CONSTANTS
int LOW = 0, 
    HIGH = 10, 
    SIZE = 100, 
    EXPERIMENT_SIZE = 100; // keeping size as 1M

int PRECISION_EXPSIZE = log10(HIGH) + 1; // Total number of digits in experiment size, if 120, 3 digits and so on
int PRECISION_VALSIZE = log10(HIGH) + 1; // Total number of digits in HIGH, if high is 256, 3 digits
int PRECISION_IDXSIZE = log10(SIZE-1) + 1; // Total number of digits in max-array-index, if array has 1000 elements, index has max 3 digits


int randIntWithExclude(int low, int high, int exclude) {
    // If you pass 10 as exclude then it will not be generated as random number at any cost
    random_device rd;  // Obtain a random number from hardware
    mt19937 eng(rd()); // Seed the generator
    uniform_int_distribution<> distribution(low, high); // Define the range
    int rand_num = distribution(eng);
    while(rand_num == exclude) rand_num = distribution(eng);
    return rand_num; // Generate the random number except exclude
}

int* getRandArray(const int& size, const int& low, const int& high, const int& exclude) {
    int* arr = new int[size];
    for(int i = 0; i < size; i++)
        arr[i] = randIntWithExclude(low, high, exclude);
    return arr;
}

int binarySearch(const int* arr, const int& size, const int& key, int& counts){
    int left = 0, right = size - 1, mid = (size - 1)/2;
    while(left < right){
        counts++; // Count iterations, which is referenced back at searchSimulator function
        if (arr[left] == key) return left;
        if (arr[right] == key) return right;
        if (arr[mid] == key) return mid;
        if (arr[mid] < key) left = mid + 1;
        if (arr[mid] > key) right = mid - 1;
        mid = (left + right)/2;
    }
    return -1;
}

void searchSimulator(const int& size, const int& low, const int& high, const int& experiment_size){
    /* Perform binary search on randomly created array*/
    // Run iterations as many as exp_size, we are resetting counts every one pass
    int theoritical_counts = floor(log2(size)); // from cmath

    // Visualization arrays ?? IGNORE following 5 lines of uncommented code if this is creating headache
    // If you are ignoring these two lines then ignore Starting-Ending visualization below
    int* stored_key_occurences = new int[high - low + 1];
    int* stored_key_search_counts = new int[high - low + 1];
    // initialize with 0
    for(int i=0;i<high-low+1;i++){
        stored_key_occurences[i] = 0;
        stored_key_search_counts[i] = 0;
    }

    for(int i = 0, counts = 0; i < experiment_size; i++, counts = 0){
        int key = randIntWithExclude(low, high, low-1);// create a random key from low to high, exclude nothing
        int* arr = getRandArray(size, low, high, key); // create array with rand-value from low to high, but key
        arr[0] = key; // our array is not sorted yet
        sort(arr, arr + size); // sort the array, we are using std::sort, please review documentation for more
        int index = binarySearch(arr, size, key, counts); // here we are passing counts with reference so it should change
        cout << "N = " << size << " | "
             << "Actual Key = " << setw(PRECISION_VALSIZE) << key << " | "
             << "Discovered Key = " << setw(PRECISION_VALSIZE) << arr[index] << " | "
             << "Index@ = " << setw(PRECISION_IDXSIZE) << index << " | "
             << "Expt. Iter Counts " << setw(PRECISION_IDXSIZE) << counts << " | "
             << "Theoritical. Iter Counts " << setw(PRECISION_IDXSIZE) << theoritical_counts << " | ";
        
        // If you are ignoring visualization ignore following two lines too
        stored_key_occurences[key-low]++; 
        stored_key_search_counts[key-low] += counts;

        if(key!=arr[index]){
            cout << " Test " << setw(PRECISION_EXPSIZE) << i+1 << " of " << experiment_size << " Failed...Terminating" << endl;
            break;
        }else
            cout << " Test " << setw(PRECISION_EXPSIZE) << i+1 << " of " << experiment_size << " Passed..." << endl;
   }
   // Starting Visualization
   cout << setw(PRECISION_EXPSIZE+PRECISION_VALSIZE+theoritical_counts+7) << setfill('-') << "" << endl;
   cout << " KEY-COUNTSBAR" << endl;
   cout << setfill(' ');
   cout << setw(PRECISION_EXPSIZE+PRECISION_VALSIZE+theoritical_counts+7) << setfill('-') << "" << endl;
   cout << setfill(' ');
   for(int i = 0; i< high - low + 1; i++){
        int avg_counts = ceil(stored_key_search_counts[i]/stored_key_occurences[i]);
        cout << setfill(' ');
        cout << "Key = " << setw(PRECISION_VALSIZE) << i + low << "|" << setw(avg_counts) << setfill('#') << "" << endl;
   }
   // Ending Visualization

}

int main(){
    searchSimulator(SIZE, LOW, HIGH, EXPERIMENT_SIZE);
}

