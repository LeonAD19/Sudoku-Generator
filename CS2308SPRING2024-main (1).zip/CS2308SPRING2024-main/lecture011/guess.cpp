#include <iostream>
#include <random>
#include <cmath>
using namespace std;

int randInt(int, int);

int LOW = 1, HIGH = 100;

void play(){
    int num = randInt(1, 100), guess_num = -1, attempt = 0;
    while(true){
        attempt++;
        cout << "Enter your guess: ";
        cin >> guess_num;
        system("clear"); // Use system("cls"); windows user
        cout << "Enter your guess: " << guess_num;
        if(guess_num > num)
            cout << " !!! TOO HIGH " << endl;
        else if(guess_num < num)
            cout << " !!! TOO LOW" << endl;
        else
            break;
    }
    cout << endl << "Congratulations!!, You finished with " 
         << attempt << " attempts." << endl;
}

int main(){
    play();
    return 0;
}

int randInt(int low, int high) {
    random_device rd;  // Obtain a random number from hardware
    mt19937 eng(rd()); // Seed the generator
    uniform_int_distribution<> distribution(low, high); // Define the range
    return distribution(eng); // Generate the random number
}


