#include <iostream>

using namespace std;

int main(){
	int arr[] = {21, 32, 93};
	cout << *(arr+3) << endl;
	return 0;
}
