#include <iostream>

using namespace std;

void someArrayCall(int arr[]){
	cout << "SIZE OF ARRAY IN SOMEFUNC " << sizeof(arr) << endl;

}

int main(){
	int arr[] = {1,2,3,4};
	cout << "SIZE OF ARRAY IN MAIN " << sizeof(arr) << endl;
	someArrayCall(arr);
}
