// This is meant to be plugged into leet code problem and therefore
// wont work by itself
class Solution {
public:
    vector<int> twoSum(vector<int>& nums, int target) {
        int Size = nums.size();
        // Searches for the first number to add
        for (int firstNum = 0; firstNum < Size - 1; firstNum++) {
            // Searfches for the second number to add
            for (int secondNum = firstNum + 1; secondNum < Size; secondNum++) {
                // If a match is found that equals target it returns those values
                if (nums[firstNum] + nums[secondNum] == target) {
                    return { firstNum,secondNum };
                }
            }

        }
        // returns if nothing is found
        return{};
    }
};