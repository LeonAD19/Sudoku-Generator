#include <iostream>

using namespace std;

void displayArray(int arr[]){
	cout << "SIZE IN OUTER FUNC " << sizeof(arr) << endl;
	arr[2] = 23;
}

int main(){
	int arr[] = 1,2,3,4,5};
	displayArray(arr);
	cout << arr[2] << endl;
	cout << "SIZE IN MAIN " << sizeof(arr) << endl;
	return 0;
}
