// This file illustrates the use of call by reference
#include <iostream>
using namespace std;
void calculateTotalSales(int &total_sales, int current_sales) {
    total_sales = total_sales + current_sales;
}
int main()
{
    /* code */
    int total_sales = 0;
    calculateTotalSales(total_sales, 20.0);
    calculateTotalSales(total_sales, 15.0);
    calculateTotalSales(total_sales, 45.0);
    cout << "Total Sales: " << total_sales << endl;
    return 0;
}

