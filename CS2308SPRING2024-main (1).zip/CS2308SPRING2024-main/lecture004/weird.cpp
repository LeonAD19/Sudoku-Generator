#include <iostream>

using namespace std;

int main() {
	int arr[] = {2, 3, 55, 99999};
	int i = 0;
	while(true){
		cout << *(arr+i)<<endl;
		if i>3:
			break;
	};
	
	cout << "arr = "<< arr << endl;
	
	cout << "*arr = " << *arr << endl;

	cout << "*(arr+1) = " << *(arr+1) << endl;
	
	cout << "*(arr+4) = " << *(arr+4) << endl;

	return 0;
}
