#include <iostream>
using namespace std;

int main(){
	int arr[] = {2, 3, 4, 5};
	for(int item:arr)
		cout << item << " ";
	cout << endl;

	for(int item:arr)
		cout << ++item << " ";
	cout << endl;
	cout <<"STARING "<< arr[2] << endl;
	for(int &item:arr)
		cout << ++item << " ";
	cout << endl;
	cout << arr[2];
	return 0;
}
