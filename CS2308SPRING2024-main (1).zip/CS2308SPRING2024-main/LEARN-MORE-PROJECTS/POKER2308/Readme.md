# DISCLAIMER \| POKER2308

* This a tough project.
* Good News: This project is not a part of our schedules, so don't worry.
* However, I encourage you to dive deep in this project and understand what is happening.
* Ask, questions outside of class, discuss with your friends.
* Try to extend the program so that you can make it a real poker play

<br>
**Following are the rules of this our poker**
<br>
* For each player, remove the community cards if they match rank with cards in player hands
* For each player, we call these sets of non-repeating-rank cards as valid cards
* Now sum the ranks of all the valid cards, Note: rank of A->14, J->11, Q->12 and K->13 and rest are equal to their numerical values
* Now players with the lowest sum-of-all rank wins
* Game might result in tie if more than one players have minimum cards

**?? HOW TO RUN ??**

* Mac/Linux users with CLion/C++17 or above installed do following
    * Run this in CLion or VSCODE
    * To run in vscode, simply open terminal at this location and run **$sh run.sh**
* Windows users with CLion/C++17 or above installed
    * Run this in CLion or VSCODE
    * To run in vscode, simply open terminal(as git_bash) at this location and run $sh run.sh
* Please follow instructions in SudokuProjects, this should be similar

**Example Output**

```text
Initializing Deck...
Deck Created without shuffle
Show Deck...
---CARDS---------------------------------------------------------------------
[ A♦] [ 2♦] [ 3♦] [ 4♦] [ 5♦] [ 6♦] [ 7♦] [ 8♦] [ 9♦] [10♦] [ J♦] [ Q♦] [ K♦] 
[ A♥] [ 2♥] [ 3♥] [ 4♥] [ 5♥] [ 6♥] [ 7♥] [ 8♥] [ 9♥] [10♥] [ J♥] [ Q♥] [ K♥] 
[ A♤] [ 2♤] [ 3♤] [ 4♤] [ 5♤] [ 6♤] [ 7♤] [ 8♤] [ 9♤] [10♤] [ J♤] [ Q♤] [ K♤] 
[ A♧] [ 2♧] [ 3♧] [ 4♧] [ 5♧] [ 6♧] [ 7♧] [ 8♧] [ 9♧] [10♧] [ J♧] [ Q♧] [ K♧] 
-----------------------------------------------------------------------------
Shuffle Deck..
---DECKS SHUFFLED------------------------------------------------------------
[ ? ] [ ? ] [ ? ] [ ? ] [ ? ] [ ? ] [ ? ] [ ? ] [ ? ] [ ? ] [ ? ] [ ? ] [ ? ] 
[ ? ] [ ? ] [ ? ] [ ? ] [ ? ] [ ? ] [ ? ] [ ? ] [ ? ] [ ? ] [ ? ] [ ? ] [ ? ] 
[ ? ] [ ? ] [ ? ] [ ? ] [ ? ] [ ? ] [ ? ] [ ? ] [ ? ] [ ? ] [ ? ] [ ? ] [ ? ] 
[ ? ] [ ? ] [ ? ] [ ? ] [ ? ] [ ? ] [ ? ] [ ? ] [ ? ] [ ? ] [ ? ] [ ? ] [ ? ] 
-----------------------------------------------------------------------------
---CARDS---------------------------------------------------------------------
[ J♤] [ K♧] [ 7♥] [ 5♧] [ 8♥] [10♦] [ J♥] [ 3♤] [ 2♥] [ Q♥] [ 9♥] [ 8♦] [ 2♦] 
[10♤] [ 7♦] [ 4♥] [ 5♥] [ 4♤] [ 2♤] [ 3♥] [ 9♦] [ 8♧] [ 6♧] [10♥] [ 9♧] [ K♥] 
[ A♧] [ 7♤] [ 6♥] [ 3♧] [ 4♧] [ J♦] [ Q♤] [ Q♦] [ K♦] [ A♥] [ A♤] [ 6♦] [ 3♦] 
[ A♦] [ 7♧] [ Q♧] [ 5♦] [ K♤] [ 6♤] [ 2♧] [10♧] [ 9♤] [ J♧] [ 8♤] [ 5♤] [ 4♦] 
-----------------------------------------------------------------------------
---VALUES--------------------------------------------------------------------
[ 11] [ 13] [  7] [  5] [  8] [ 10] [ 11] [  3] [  2] [ 12] [  9] [  8] [  2] 
[ 10] [  7] [  4] [  5] [  4] [  2] [  3] [  9] [  8] [  6] [ 10] [  9] [ 13] 
[ 14] [  7] [  6] [  3] [  4] [ 11] [ 12] [ 12] [ 13] [ 14] [ 14] [  6] [  3] 
[ 14] [  7] [ 12] [  5] [ 13] [  6] [  2] [ 10] [  9] [ 11] [  8] [  5] [  4] 
-----------------------------------------------------------------------------
Hit Enter to begin the game...

---CARDS---------------------------------------------------------------------
[ J♤] [ K♧] [ 7♥] [ 5♧] [ 8♥] [10♦] [ J♥] [ 3♤] [ 2♥] [ Q♥] [ 9♥] [ 8♦] [ 2♦] 
[10♤] [ 7♦] [ 4♥] [ 5♥] [ 4♤] [ 2♤] [ 3♥] [ 9♦] [ 8♧] [ 6♧] [10♥] [ 9♧] [ K♥] 
[ A♧] [ 7♤] [ 6♥] [ 3♧] [ 4♧] [ J♦] [ Q♤] [ Q♦] [ K♦] [ A♥] [ A♤] [ 6♦] [ 3♦] 
[ A♦] [ 7♧] [ Q♧] [ 5♦] [ K♤] [ 6♤] [ 2♧] [10♧] [ 9♤] [ J♧] [ 8♤] [ 5♤] [ 4♦] 
-----------------------------------------------------------------------------
---HANDS CARDS---------------------------------------------------------------
              Keshav : [ J♤] [10♦] 
                Anar : [ K♧] [ J♥] 
               James : [ 7♥] [ 3♤] 
                John : [ 5♧] [ 2♥] 
                Evry : [ 8♥] [ Q♥] 
-----------------------------------------------------------------------------
---COMMUNITY CARDS-----------------------------------------------------------
                Turn : [ 8♦] [ 2♦] [10♤] 
               River : [ 4♥] 
                Flop : [ 4♤] 

---CARDS---------------------------------------------------------------------

            [ 2♤] [ 3♥] [ 9♦] [ 8♧] [ 6♧] [10♥] [ 9♧] [ K♥] [ A♧] [ 7♤] [ 6♥] 
[ 3♧] [ 4♧] [ J♦] [ Q♤] [ Q♦] [ K♦] [ A♥] [ A♤] [ 6♦] [ 3♦] [ A♦] [ 7♧] [ Q♧] 
[ 5♦] [ K♤] [ 6♤] [ 2♧] [10♧] [ 9♤] [ J♧] [ 8♤] [ 5♤] [ 4♦] [ 9♥] [ 7♦] [ 5♥] 
-----------------------------------------------------------------------------
---STATS---------------------------------------------------------------------
              Keshav: [18] | [ 8♦] [ 2♦] [ 4♥] [ 4♤] 
                Anar: [28] | [ 8♦] [ 2♦] [10♤] [ 4♥] [ 4♤] 
               James: [28] | [ 8♦] [ 2♦] [10♤] [ 4♥] [ 4♤] 
                John: [26] | [ 8♦] [10♤] [ 4♥] [ 4♤] 
                Evry: [20] | [ 2♦] [10♤] [ 4♥] [ 4♤] 
---WINNERS-------------------------------------------------------------------
  Congratulations!! Keshav,
```
